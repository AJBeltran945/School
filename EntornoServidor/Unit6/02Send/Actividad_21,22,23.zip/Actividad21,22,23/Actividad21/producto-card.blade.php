ACTIVIDAD 21

<div style="border:1px solid #ccc; padding:10px; margin:10px;">
    <h2>{{ $nombre }}</h2>
    <p>{{ $descripcion }}</p>
    <strong>Precio: ${{ $precio }}</strong>
</div>


