<?php
// Interface definition for Shape
interface Shape {
    // Method to calculate area
    public function calculateArea();

    // Method to calculate perimeter
    public function calculatePerimeter();
}
?>
