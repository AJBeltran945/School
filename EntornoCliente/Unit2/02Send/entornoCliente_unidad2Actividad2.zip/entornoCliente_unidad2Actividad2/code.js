function login(){
    let user = prompt("Quien eres?")

    console.log(user)

    if (user === "Administrador"){
        let paswrd = prompt("Dime la contraseña:")

        if (paswrd === "Elmejor"){
            alert("✅ BIENVENIDO ✅")
        } else if (paswrd === null){
            alert("Cancelado!")
        }else{
            alert("❌ Contraseña incorrecta ❌")
        }
    } else if (user === null){
        alert("Cancelado!")
    } else {
        alert("❔ No te conozco ❔")
    }
}